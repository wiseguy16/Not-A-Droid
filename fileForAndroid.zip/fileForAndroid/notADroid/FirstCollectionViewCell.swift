//
//  FirstCollectionViewCell.swift
//  NacdNews
//
//  Created by Gregory Weiss on 9/9/16.
//  Copyright © 2016 Gregory Weiss. All rights reserved.
//

import UIKit

class FirstCollectionViewCell: UICollectionViewCell
{
    
    
    @IBOutlet weak var firstTitleLabel: UILabel!
    
    @IBOutlet weak var firstDescriptionLabel: UILabel!
    
    @IBOutlet weak var firstMiscLabel: UILabel!
    
    @IBOutlet weak var firstImageView: UIImageView!
    
    @IBOutlet weak var activityViewServices: UIActivityIndicatorView!
    
}
//