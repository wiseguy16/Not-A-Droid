//
//  StudySession.swift
//  Northland Church
//
//  Created by Gregory Weiss on 1/11/17.
//  Copyright © 2017 NorthlandChurch. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift

class StudySession
{
    var studyWeekNumber: Int? = 0
    var studyWeekTitle: String? = ""
    var studyWeekURL: String? = ""
    
}

//
//