//
//  BibleCell.swift
//  NacdFeatured
//
//  Created by Gregory Weiss on 11/8/16.
//  Copyright © 2016 NorthlandChurch. All rights reserved.
//

import UIKit

class BibleCell: UICollectionViewCell
{
    
    @IBOutlet weak var title1Label: UILabel!
    
    @IBOutlet weak var title2Label: UILabel!
    
    @IBOutlet weak var authorLabel: UILabel!
    
    
    @IBOutlet weak var actualBodyLabel: UILabel!
    
    
    @IBOutlet weak var dateLabel: UILabel!
    
    
    
    
}
