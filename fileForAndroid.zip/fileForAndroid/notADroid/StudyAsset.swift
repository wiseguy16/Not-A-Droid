//
//  StudyAsset.swift
//  Northland Church
//
//  Created by Gregory Weiss on 1/13/17.
//  Copyright © 2017 NorthlandChurch. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift

class StudyAsset
{
    var assetID: Int? = 0
    var assetTitle: String? = ""
    var assetURL: String? = ""
    var assetDescrip: String? = ""
    
}


